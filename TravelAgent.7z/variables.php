
<?php
$myLinks= array("https://www.easytourchina.com/tour-c8-china-tea-tours"=>"EasyTourChina"
									,"https://sevencups.com/china-tea-tours/"=>"Seven Cups(Fine Chinese Teas)"
									,"https://www.worldteatours.com/"=>"World Tea Tours"
									,"https://boutiquejapan.com/tea-in-japan/"=>"Boutique Japan"
									,"https://www.japanvisitor.com/japanese-culture/food/tea"=>"Tea in Japan"
									,"http://www.littletreetea.com/tours/japan-tea-tour-2018/"=>"little Tree Tea"
									);
?>