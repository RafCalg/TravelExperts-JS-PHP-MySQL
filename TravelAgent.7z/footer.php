

<footer>
	<h5 class="FooterStyle" align = 'right' >&copyCopyright 2019 Drink Tea & Travel. All Rights Reserved</h5>
</footer>

